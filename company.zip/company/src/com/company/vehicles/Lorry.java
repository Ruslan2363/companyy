package com.company.vehicles;
import  com.company.vehicles.Car;
import com.company.details.Engine;
public class Lorry extends Car{
    public String  вантажопідйомністюКузова;

    public Lorry(int потужність,String виробник,String маркаАвтомобіля,String класАвтомобіля,int вага,String вантажопідйомністюКузова){
         super(потужність,виробник,маркаАвтомобіля,класАвтомобіля,вага);
         this.вантажопідйомністюКузова=вантажопідйомністюКузова;
    }
    public String getВантажопідйомністюКузова(){

        return вантажопідйомністюКузова;
    }

    public void setВантажопідйомністюКузова(String вантажопідйомністюКузова) {
        this.вантажопідйомністюКузова = вантажопідйомністюКузова;
    }
    @Override
    public String toString() {
        return super.toString()+"; Lorry:"+" вантажопідйомністюКузова-"+вантажопідйомністюКузова+" ;";
    }
}

